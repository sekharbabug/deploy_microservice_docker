package com.barath.customer.app;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


@SpringBootTest(properties={"spring.cloud.discovery.enabled = false"})
public class CustomerApplicationTests {
	
	

	public void contextLoads() {
	}
	
	

}
